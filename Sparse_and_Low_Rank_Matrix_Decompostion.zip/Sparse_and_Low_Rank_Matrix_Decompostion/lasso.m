function [z] = lasso(A, b, lambda1, mu2, f, betae)

MAX_ITER = 50000;

[~, n] = size(A);
% save a matrix-vector multiply
Atb = A'*b;

z = zeros(n,size(b,2));
u = zeros(n,size(b,2));
Ident = eye(size(A,2));
% cache the factorization
rho = mu2;
maxRho = 1e7; % Set the maximum mu

for k = 1:MAX_ITER
 
% x-update
    x = (f*betae*(A'*A) + rho*Ident) \ (betae*Atb + rho*z - rho*u);

    temp1 = x + u; 
    z = solve_l1l2_C(temp1, lambda1/rho);

    % u-update
    u = u + (x - z);   
    rho = min(maxRho, rho*1.1); 
    
   if(norm(x - z, 'fro') <= 1e-4)
       break
   end
end
