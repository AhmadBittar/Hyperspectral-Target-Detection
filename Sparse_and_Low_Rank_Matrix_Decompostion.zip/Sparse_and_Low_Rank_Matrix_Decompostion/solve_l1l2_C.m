function [Z] = solve_l1l2_C(W,lambda)
n = size(W,2);
Z = W;
for i=1:n
    Z(:,i) = solve_l2(W(:,i),lambda);
end
end

function [x] = solve_l2(w,lambda)
nw = norm(w);
if nw>lambda
    x = (nw-lambda)*w/nw;
else
    x = zeros(length(w),1);
end
end