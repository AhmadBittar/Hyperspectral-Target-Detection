clear;
close all;
clc;

%Read the hyperspectral image
image1 = multibandread('f970619t01p02_r02_sc03.a.rfl', [512,614,224], 'int16', 0, 'bip', 'ieee-be');
image2 = multibandread('f970619t01p02_r02_sc04.a.rfl', [512,614,224], 'int16', 0, 'bip', 'ieee-be');
DD1 = [image1; image2];
good_bands = [5:103 114:147 168:220];
DD1 = DD1(:,:, good_bands);

DD1 = DD1(389:489, 379:479, :);

s = size(DD1);
m = s(3);
range_m = (1:m);

DD1 = double(DD1( : , : , range_m));
minD = min(DD1(:));
maxD = max(DD1(:));
DD1 = (DD1 - minD) / (maxD-minD);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
wavelength_image = load('wavelength_image.mat');
wavelength_target = load('wavelength_target.mat');

wavelength_image = wavelength_image.wavelength_image;
wavelength_image = wavelength_image(good_bands);
wavelength_image = wavelength_image/1000;

wavelength_target = wavelength_target.wavelength_target;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

target1 = importdata('jarosit1.spc');
target2 = importdata('jarosit2.spc');
target3 = importdata('jarosit3.spc');
target4 = importdata('jarosit4.spc');
target5 = importdata('jarosit5.spc');
target6 = importdata('jarosit6.spc');

index1 = find(target1.data(:,1) == 3.991000e-01);
index2 = find(target1.data(:,1) == 2.496000);

target1 = target1.data(index1:index2,3);
target2 = target2.data(index1:index2,3);
target3 = target3.data(index1:index2,3);
target4 = target4.data(index1:index2,3);
target5 = target5.data(index1:index2,3);
target6 = target6.data(index1:index2,3);

Final_target1 = interp1(wavelength_target, target1, wavelength_image);
Final_target2 = interp1(wavelength_target, target2, wavelength_image);
Final_target3 = interp1(wavelength_target, target3, wavelength_image);
Final_target4 = interp1(wavelength_target, target4, wavelength_image);
Final_target5 = interp1(wavelength_target, target5, wavelength_image);
Final_target6 = interp1(wavelength_target, target6, wavelength_image);


Final_target = (Final_target1 + Final_target2 + Final_target3 + Final_target4 + Final_target5 + Final_target6)/6;

%it is for alpha values
f = [0.1];

%Developing a detector to plot the ROC curves for Strategy two%%%%%%%%%%%%%
Masquex = 5; % has to be odd
Masquey =5; % has to be odd
 
Masque = ones(Masquex, Masquey);
cellguard = [0]; %
Masque(1 + (Masquex - 1) / 2 + cellguard, 1 + (Masquey - 1) / 2 + cellguard) = zeros(length(cellguard), length(cellguard));
NI = find(reshape(Masque, Masquex * Masquey, 1) == 1);
N_ref = length(NI); % Number of secondary data
II = 1 : s(1) - (Masquex - 1);
JJ = 1 : s(2) - (Masquey - 1);

detec = zeros(length(II), length(JJ), length(f));

for ff = 1 : length(f)

%Adding synthetic target into the original hyperspectral image
for ii1 = 12 : 17
    for jj1 = 47 : 49
DD1(ii1, jj1,:) = f(ff)*Final_target + (1-f(ff))*squeeze(DD1(ii1, jj1,:));
    end
end

for ii2 = 23 : 28
    for jj2 = 47 : 49
DD1(ii2, jj2,:) = f(ff)*Final_target + (1-f(ff))*squeeze(DD1(ii2, jj2,:));
    end
end

for ii3 = 34 : 39
    for jj3 = 47 : 49
DD1(ii3, jj3,:) = f(ff)*Final_target + (1-f(ff))*squeeze(DD1(ii3, jj3,:));
    end
end

for ii4 = 45 : 50
    for jj4 = 47 : 49
DD1(ii4, jj4,:) = f(ff)*Final_target + (1-f(ff))*squeeze(DD1(ii4, jj4,:));
    end
end

for ii5 = 56 : 61
    for jj5 = 47 : 49
DD1(ii5, jj5,:) = f(ff)*Final_target + (1-f(ff))*squeeze(DD1(ii5, jj5,:));
    end
end

for ii6 = 67 : 72
    for jj6 = 47 : 49
DD1(ii6, jj6,:) = f(ff)*Final_target + (1-f(ff))*squeeze(DD1(ii6, jj6,:));
    end
end

for ii7 = 78 : 83
    for jj7 = 47 : 49
DD1(ii7, jj7,:) = f(ff)*Final_target + (1-f(ff))*squeeze(DD1(ii7, jj7,:));
    end
end

%Target dictionary A_t
A_t = [Final_target1 Final_target2 Final_target3 Final_target4 Final_target5 Final_target6]; 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% Strategy two DETECTION %%%%%%%%%%%%%%%%%%%%%%%%
C = reshape(DD1, [s(1)*s(2), s(3)]); % m * e where e = H * W 

tau = 0.05;
lambda1 = 0.02;
betae = 2; 
bau = 1;

% % 
tol = 1e-2;
maxiter =5000;  
[A_hat alpha iter] = inexact_alm_rpca_new1(C, lambda1, tau, tol, maxiter, A_t, bau, betae);

% 
E_hat = alpha'*A_t';
Noise_hat = C - A_hat - E_hat;

A_hatt = reshape(A_hat, [s(1) s(2) s(3)]);
E_hatt = reshape(E_hat, [s(1) s(2) s(3)]);
Noise_hatt = reshape(Noise_hat, [s(1) s(2) s(3)]);

% 
DD2 = mean(DD1.^2, 3);
DD3 = mean(A_hatt.^2, 3);
DD4 = mean(E_hatt.^2, 3);
DD5 = mean(Noise_hatt.^2, 3);

%
figure
imagesc(10*log10(DD2))
colormap(gray)

% 
figure
imagesc(10*log10(DD3));
colormap(gray)

% 
figure
imagesc(10*log10(DD4));
colormap(gray)

%
figure
imagesc(10*log10(DD5));
colormap(gray) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%% ROC CURVES PLOTS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for ii = II
    for jj = JJ

A1 = E_hatt(ii : ii + (Masquex - 1), jj : jj + (Masquey - 1), :); 
Noise_ref1 = reshape(A1, Masquex * Masquey, m).'; 

Noise_obs = Noise_ref1(:, Masquex * (Masquey - 1) / 2 + (Masquex - 1) / 2 + 1); % the pixel under test

detec(ii, jj, ff) = abs(Final_target' * Noise_obs)^2 / abs(Final_target' * Final_target); 
    end
    ii
end
ff
end

figure
imagesc(10*log10(detec));
colormap(gray)

%Plot the ROC curves%%%%%%%%%%%%%%%%%
DD3 = DD1(ceil(Masquex/2):s(1) - (ceil(Masquex/2)-1), ceil(Masquey/2):s(2) - (ceil(Masquey/2)-1),:); 
target1 = DD3(12-2 : 17-2, 47-2 : 49-2, :); %chosen from DD3
target2 = DD3(23-2 : 28-2, 47-2 : 49-2, :);%chosen from DD3
target3 = DD3(34-2 : 39-2, 47-2 : 49-2, :);%chosen from DD3
target4 = DD3(45-2 : 50-2, 47-2 : 49-2, :);%chosen from DD3
target5 = DD3(56-2 : 60-2, 47-2 : 49-2, :);%chosen from DD3
target6 = DD3(67-2 : 72-2, 47-2 : 49-2, :);%chosen from DD3
target7 = DD3(78-2 : 83-2, 47-2 : 49-2, :);%chosen from DD3


det1 = detec(:,:,1);
a1 = sort(det1(:),1,'descend');
pd1 = zeros(length(a1), length(f));
pfa1 = zeros(length(a1), length(f));

for gg = 1 : length(f)    
det1 = detec(:,:,gg);

% 
a1 = sort(det1(:),1,'descend');

% 
total_targets = size(target1,1)*size(target1,2) + size(target2,1)*size(target2,2) + size(target3,1)*size(target3,2) + size(target4,1)*size(target4,2) + size(target5,1)*size(target5,2) + size(target6,1)*size(target6,2) + size(target7,1)*size(target7,2);
total_pixels_testregion = size(DD3,1)*size(DD3,2);

for k = 1 : length(a1)
true_detection1 = 0;
false_detection1 = 0;
% 
for ii = 1 : size(DD3,1)
for jj = 1 : size(DD3,2)
if((ii>=12-2 && ii<=17-2 && jj>=47-2 && jj<=49-2) || (ii>=23-2 && ii<=28-2 && jj>=47-2 && jj<=49-2) || (ii>=34-2 && ii<=39-2 && jj>=47-2 && jj<=49-2) || (ii>=45-2 && ii<=50-2 && jj>=47-2 && jj<=49-2) || (ii>=56-2 && ii<=60-2 && jj>=47-2 && jj<=49-2) || (ii>=67-2 && ii<=72-2 && jj>=47-2 && jj<=49-2) || (ii>=78-2 && ii<=83-2 && jj>=47-2 && jj<=49-2))
% 
if(det1(ii,jj) >= a1(k))
true_detection1 = true_detection1 + 1;
end 
% % % % % 
% 
else
if(det1(ii,jj) >= a1(k))
false_detection1 = false_detection1 + 1;
end
% % % % % 
% 
end
end
end
pd1(k, gg) = true_detection1 / total_targets;
pfa1(k, gg) = false_detection1 / total_pixels_testregion;
end
gg
end
% 
% 
figure
plot(pfa1(:)',pd1(:)', 'm:', ...
'LineWidth',4,...
'MarkerSize',3);
legend('Strategy two');
% text(0.55,0.37, '\bf\alpha = 0.05','Color','black','FontSize',32)
xlabel('P_{fa}')
ylabel('P_{d}')

