function [A_hat S_hat iter] = inexact_alm_rpca_l1l2(D, lambda1, tau, tol, maxIter, betae)

% Oct 2009
% This matlab code implements the inexact augmented Lagrange multiplier 
% method for Robust PCA.
%
% D - m x n matrix of observations/data (required input)
%
% lambda - weight on sparse error term in the cost function
%
% tol - tolerance for stopping criterion.
%     - DEFAULT 1e-7 if omitted or -1.
%
% maxIter - maximum number of iterations
%         - DEFAULT 1000, if omitted or -1.
% 
% Initialize A,E,Y,u
% while ~converged 
%   minimize (inexactly, update A and E only once)
%     L(A,E,Y,u) = |A|_* + lambda * |E|_1 + <Y,D-A-E> + mu/2 * |D-A-E|_F^2;
%   Y = Y + \mu * (D - A - E);
%   \mu = \rho * \mu;
% end
%
% Minming Chen, October 2009. Questions? v-minmch@microsoft.com ; 
% Arvind Ganesh (abalasu2@illinois.edu)
%
% Copyright: Perception and Decision Laboratory, University of Illinois, Urbana-Champaign
%            Microsoft Research Asia, Beijing

addpath PROPACK;

[m n] = size(D);

if nargin < 3
    tol = 1e-6;
elseif tol == -1
    tol = 1e-6;
end

if nargin < 4
    maxIter = 5000;
elseif maxIter == -1
    maxIter = 5000;
end

% initialize
A_hat = zeros( m, n);
S_hat = zeros(m, n);
d_norm = norm(D, 'fro');

iter = 0;
total_svd = 0;
sv = 10;

% while ~converged 
 for kkr = 1:5000000
    iter = iter + 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A_hat_old = A_hat;
    if choosvd(n, sv) == 1
        [U S V] = lansvd(D - S_hat, sv, 'L');
    else
        [U S V] = svd(D - S_hat, 'econ');
    end
    diagS = diag(S);
    svp = length(find(diagS > (tau/betae)));
    if svp < sv
        sv = min(svp + 1, n);
    else
        sv = min(svp + round(0.05*n), n);
    end
    A_hat = U(:, 1:svp) * diag(diagS(1:svp) - (tau/betae)) * V(:, 1:svp)';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%% Compute alpha %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
S_hat_old = S_hat;
SS = D - A_hat;
S_hat = solve_l1l2(SS, lambda1/betae);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    total_svd = total_svd + 1;
%     Z = D - A_hat - alpha'*A_t';  
%     lambda2 = max(minlambda2, lambda2*0.5);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    %% stop Criterion    
%     stopCriterion = norm(Z, 'fro') / d_norm;
%     if (stopCriterion < tol)
%         converged = true;
%     end    
%     
%     if mod( total_svd, 10) == 0
%         disp(['#svd ' num2str(total_svd) ' r(A) ' num2str(rank(A_hat))...
%             ' stopCriterion ' num2str(stopCriterion)]);
%     end    
%     
%     if ~converged && iter >= maxIter
%         disp('Maximum iterations reached') ;
%         converged = 1 ;       
%     end
% end

% stopCriterion = norm((A_hat - A_hat_old), 'fro')/ d_norm;
%     if (stopCriterion < tol)
%         converged = true;
%     end 
%     
%     if mod( total_svd, 10) == 0
%         disp(['#svd ' num2str(total_svd) ' r(A) ' num2str(rank(A_hat))...
%             ' stopCriterion ' num2str(stopCriterion)]);
%     end  

stopCriterion1 = norm((A_hat - A_hat_old), 'fro')/ d_norm;
stopCriterion2 = norm((S_hat - S_hat_old), 'fro')/ d_norm;
    if (stopCriterion1 < 1e-4 && stopCriterion2 < 1e-4)%0.0020793
        break
    end
    disp(['#svd ' num2str(total_svd) ' r(B) ' num2str(rank(A_hat))...
            ' stopCriterion1 ' num2str(stopCriterion1) ' stopCriterion2 ' num2str(stopCriterion2)]);
% disp(['#iteration' num2str(kkr) ' r(B) ' num2str(rank(A_hat))]);
end
end
