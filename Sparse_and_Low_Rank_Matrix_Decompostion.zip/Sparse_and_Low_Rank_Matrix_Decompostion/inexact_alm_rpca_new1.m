function [A_hat alpha iter] = inexact_alm_rpca_new1(D, lambda1, tau, tol, maxIter, A_t, f, betae)
addpath PROPACK;

[m n] = size(D);

if nargin < 2
    lambda1 = 1 / sqrt(m);
end

if nargin < 3
    tol = 1e-6;
elseif tol == -1
    tol = 1e-6;
end

if nargin < 4
    maxIter = 5000;
elseif maxIter == -1
    maxIter = 5000;
end

% initialize
A_hat = zeros(m,n);
alpha = zeros(size(A_t,2),m);
d_norm = norm(D, 'fro');

iter = 0;
total_svd = 0;
sv = 10;

% while ~converged 
 for kkr = 1:500000
    iter = iter + 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
A_hat_old = A_hat;
    if choosvd(n, sv) == 1
        [U S V] = lansvd(D - f*(alpha'*A_t'), sv, 'L');
    else
        [U S V] = svd(D - f*(alpha'*A_t'), 'econ');
    end
    diagS = diag(S);
    svp = length(find(diagS > (tau/betae)));
    if svp < sv
        sv = min(svp + 1, n);
    else
        sv = min(svp + round(0.05*n), n);
    end
    A_hat = U(:, 1:svp) * diag(diagS(1:svp) - (tau/betae)) * V(:, 1:svp)';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%% Compute alpha %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E_hat_old = f*(A_t*alpha)';
mu2 = 1e-4; % Set rho to be quite low to start with;
[alpha] = lasso(A_t, (D - A_hat)', lambda1, mu2, f, betae);
E_hat = f * (A_t*alpha)';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    total_svd = total_svd + 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


stopCriterion1 = norm((A_hat - A_hat_old), 'fro')/ d_norm;
stopCriterion2 = norm((E_hat - E_hat_old), 'fro')/ d_norm;
    if (stopCriterion1 < 1e-4 && stopCriterion2 < 1e-4)
        break
    end
    disp(['#svd ' num2str(total_svd) ' r(B) ' num2str(rank(A_hat))...
            ' stopCriterion1 ' num2str(stopCriterion1) ' stopCriterion2 ' num2str(stopCriterion2)]);
end
end